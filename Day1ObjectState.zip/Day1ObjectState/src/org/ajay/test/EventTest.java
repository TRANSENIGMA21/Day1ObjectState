package org.ajay.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ajay.dao.EventManager;
import com.ajay.entities.Event;
import com.ajay.entities.EventKey;

public class EventTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
	
		
		EventManager eventManager=new EventManager();
		EventKey eventKey=new EventKey();
		eventKey.setEventId(3);
		eventKey.setTrainerId(350);
		Event event=new Event();
		event.setEventid(eventKey);
		event.setDuration(5);
		event.setLocation("Chennai");
		event.setEventName("Rest Trainning");
		assertTrue(eventManager.AddEvent(event));
	}

}
