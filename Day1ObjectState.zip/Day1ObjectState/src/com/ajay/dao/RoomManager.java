package com.ajay.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.ajay.entities.Room;
import com.ajay.resources.HibernateUtil;

public class RoomManager {
	
	private SessionFactory factory;
	private Session session;
	
	
	
	
	
	public RoomManager() {
		super();
		// TODO Auto-generated constructor stub
		factory=HibernateUtil.GetFactory();
	}



	public RoomManager(SessionFactory factory, Session session) {
		super();
		this.factory = factory;
		this.session = session;
	}



	public boolean AddRoom(Room room){
		
		boolean status=false;
		
		session=factory.openSession();
		session.beginTransaction();
		try {
			session.save(room);
			session.getTransaction().commit();
			status=true;
		} catch (HibernateException ex) {
			// TODO Auto-generated catch block
			session.getTransaction().rollback();
		}
		session.close();
		
		return status;
		
	}
	
	public  List<Room> GetAllRooms(){
		session=factory.openSession();
		
		return session.createQuery("from Room").list();
	}
	
	public boolean UpdateRoom(int room_no){
		boolean status=false;
		session=factory.openSession();
		Room room=(Room) session.get(Room.class, room_no);
		room.setCapacity(50);
		room.setSystem_Avl(false);
		session.beginTransaction();
		try {
			//session.update(room);
			session.getTransaction().commit();
			status=true;
		} catch (HibernateException ex) {
			// TODO Auto-generated catch block
			session.getTransaction().rollback();
		}
		session.close();
		return status;
		
	}
/*	public boolean DeleteRoom(int room_no){
		boolean status=false;
		session=factory.openSession();
		Room room=(Room) session.get(Room.class, room_no);
		
		session.beginTransaction();
		try {
			session.delete(room);
			session.getTransaction().commit();
			status=true;
		} catch (HibernateException ex) {
			// TODO Auto-generated catch block
			session.getTransaction().rollback();
		}
		session.close();
		return status;
	}*/
	
	public boolean roomEvict_Clear(int room_no1, int room_no2){
		boolean status=false;
		session=factory.openSession();
		Room obj1=(Room)session.get(Room.class, room_no1);
		Room obj2=(Room)session.get(Room.class, room_no2);
		
		session.clear();
		/*session.evict(obj2);*/
		session.beginTransaction();
		obj1.setCapacity(25);
		obj2.setCapacity(100);
		
		session.getTransaction().commit();
		status=true;
		session.close();
		
		return status;
		
	}
	public boolean SessionClose( int room_no){
		boolean status=false;
		session=factory.openSession();
		
	
		Room room=(Room) session.get(Room.class, room_no);
		session.close();
		room.setCapacity(67);
		session.getTransaction().commit();
		status=true;
		return status;
		
	}
	
	
	
	
	
	
}
