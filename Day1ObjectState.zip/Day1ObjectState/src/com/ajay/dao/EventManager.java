package com.ajay.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.ajay.entities.Event;
import com.ajay.resources.HibernateUtil;

public class EventManager {

	
	private  SessionFactory  factory;
	private Session session;

	public EventManager() {
		factory=HibernateUtil.GetFactory();
	}
	public boolean AddEvent(Event event){
		boolean status=false;
		session=factory.openSession();
		session.beginTransaction();
		try {
			session.save(event);
			session.getTransaction().commit();
			status=true;
		} catch (HibernateException hib) {
			// TODO Auto-generated catch block
			session.getTransaction().rollback();
		}
		return status;
		
	}
	
	
	
}
