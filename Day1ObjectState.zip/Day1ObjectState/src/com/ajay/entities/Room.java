package com.ajay.entities;

public class Room {

	private int room_no;
	private String location;
	private int capacity;
	private boolean system_Avl;
	private boolean projector_Avl;
	
	
	public int getRoom_no() {
		return room_no;
	}
	public void setRoom_no(int room_no) {
		this.room_no = room_no;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	public boolean isSystem_Avl() {
		return system_Avl;
	}
	public void setSystem_Avl(boolean system_Avl) {
		this.system_Avl = system_Avl;
	}
	public boolean isProjector_Avl() {
		return projector_Avl;
	}
	public void setProjector_Avl(boolean projector_Avl) {
		this.projector_Avl = projector_Avl;
	}

	
	
}
