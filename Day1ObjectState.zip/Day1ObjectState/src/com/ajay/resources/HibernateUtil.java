package com.ajay.resources;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {
	

	
	public static SessionFactory GetFactory(){
		return new Configuration().configure("com/ajay/resources/hibernate.cfg.xml").buildSessionFactory();
		
	}

}
