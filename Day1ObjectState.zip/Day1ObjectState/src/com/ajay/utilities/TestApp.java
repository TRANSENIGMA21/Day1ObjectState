package com.ajay.utilities;

import java.util.Scanner;

import com.ajay.dao.EventManager;
import com.ajay.dao.RoomManager;
import com.ajay.entities.Event;
import com.ajay.entities.EventKey;
import com.ajay.entities.Room;

public class TestApp {
	
	public static void main(String[] args) {
		
		
		
		EventManager eventManager=new EventManager();
		EventKey eventKey=new EventKey();
		eventKey.setEventId(1);
		eventKey.setTrainerId(249);
		Event event=new Event();
		event.setEventid(eventKey);
		event.setDuration(5);
		event.setLocation("Chennai");
		event.setEventName("Hibernate Trainning");
		eventManager.AddEvent(event);
		
	/*	
		RoomManager roomManager=new RoomManager();
		Room room=new Room();
		room.setCapacity(62);
		room.setLocation("tbm");
		room.setProjector_Avl(true);
		room.setSystem_Avl(true);
		
		if(roomManager.AddRoom(room)){
			System.out.println("Record Added");
		for(Room room:roomManager.GetAllRooms()){
			
			System.out.println(room.getCapacity());
			System.out.println(room.getRoom_no());
		}
		
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter Room No1");
		int room_no1=scanner.nextInt();
	
		
		System.out.println("Enter Room No2");
		int room_no2=scanner.nextInt();
		roomManager.UpdateRoom(room_no);
		roomManager.DeleteRoom(room_no);
		
		roomManager.roomEvict_Clear(room_no1, room_no2 );
		
		roomManager.SessionClose(room_no1);*/
		}
		
	}


